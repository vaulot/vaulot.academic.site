
## ----libraries, message=FALSE-----------------------------------------------------------------------------------------------
library("phyloseq")
library("ggplot2")      # graphics
library("readxl")       # necessary to import the data from Excel file
library("dplyr")        # filter and reformat data frames
library("tibble")       # Needed for converting column to row names


## --- Read the files --------------------------------------------------------------------------------------------------------
  otu_mat<- read_excel("data/CARBOM metabarcodes.xlsx", sheet = "OTU matrix")
  tax_mat<- read_excel("data/CARBOM metabarcodes.xlsx", sheet = "Taxonomy table")
  samples_df <- read_excel("data/CARBOM metabarcodes.xlsx", sheet = "Samples")


## ---OTU mastrix ----------------------------------------------------------------------------------------------------------
  otu_mat <- otu_mat %>%
    tibble::column_to_rownames("otu") 
  
  otu_mat <- as.matrix(otu_mat)

## --- Taxonomy and OTU matrix ---------------------------------------------------------------------------------------------

  tax_mat <- tax_mat %>% 
    tibble::column_to_rownames("otu")

  samples_df <- samples_df %>% 
    tibble::column_to_rownames("sample") 

  tax_mat <- as.matrix(tax_mat)


## --- Build Phyolseq file --------------------------------------------------------------------------------------------
  OTU = otu_table(otu_mat, taxa_are_rows = TRUE)
  TAX = tax_table(tax_mat)
  samples = sample_data(samples_df)
  
  carbom <- phyloseq(OTU, TAX, samples)
  carbom


## --- Check the different Phyloseq objects ----------------------------------------------------------------------------
  sample_names(carbom)
  rank_names(carbom)
  sample_variables(carbom)


## --- Remove only samples wanted ----------------------------------------------------------------------------------
  carbom <- subset_samples(carbom, Select_18S_nifH =="Yes")
  carbom


## ---- Keep only photosynthetic groups --------------------------------------------------------------------------------------
  carbom <- subset_taxa(carbom, Division %in% c("Chlorophyta", "Dinophyta", "Cryptophyta", 
                                                "Haptophyta", "Ochrophyta", "Cercozoa"))
  carbom <- subset_taxa(carbom, !(Class %in% c("Syndiniales", "Sarcomonadea")))
  carbom


## ---- Normalize the data ---------------------------------------------------------------------------------------------------
  total = median(sample_sums(carbom))
  standf = function(x, t=total) round(t * (x / sum(x)))
  carbom = transform_sample_counts(carbom, standf)


## --- Bar plot --------------------------------------------------------------------------------------------------------------
  plot_bar(carbom, fill = "Division")


## ---- Arrange bar plot------------------------------------------------------------------------------------------------------
  plot_bar(carbom, fill = "Division") + 
  geom_bar(aes(color=Division, fill=Division), stat="identity", position="stack")


## --- Merge samples together ------------------------------------------------------------------------------------------------
  carbom_fraction <- merge_samples(carbom, "fraction")
  plot_bar(carbom_fraction, fill = "Division") + 
  geom_bar(aes(color=Division, fill=Division), stat="identity", position="stack")


## ---- Look only at green algae ------------------------------------------------------------------------------------------

  carbom_chloro_ps <- subset_taxa(carbom, 
                                  Division %in% c("Chlorophyta"))

  carbom_chloro_df <- psmelt(carbom_chloro_ps) %>% 
    group_by(fraction, level) %>%
    mutate(Abundance_pct = Abundance/sum(Abundance) * 100) 
  
  ggplot(carbom_chloro_df)  +
    geom_bar(aes(x= Division, y = Abundance_pct, fill=Genus), 
             stat="identity", 
             position="stack") +
    facet_grid(rows = vars(level), cols=vars(fraction))

  
## --- Plot richness-----------------------------------------------------------------------------------------------------
  plot_richness(carbom, measures=c("Chao1", "Shannon"))

  plot_richness(carbom, measures=c("Chao1", "Shannon"), x="level", color="fraction")


## ---------------------------------------------------------------------------------------------------------------------------
  carbom.ord <- ordinate(carbom, "NMDS", "bray")

  plot_ordination(carbom, carbom.ord, type="taxa", color="Class", shape= "Division", 
                  title="OTUs")

  plot_ordination(carbom, carbom.ord, type="taxa", color="Class", 
                title="OTUs", label="Class") + 
                facet_wrap(~Division, 3)

  plot_ordination(carbom, carbom.ord, type="samples", color="fraction", 
                shape="level", title="Samples") + geom_point(size=3)

  plot_ordination(carbom, carbom.ord, type="split", color="Class", 
                  shape="level", title="biplot", label = "station") +  
    geom_point(size=3)

