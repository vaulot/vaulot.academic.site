pkgload::load_all(".")

metapr2App()