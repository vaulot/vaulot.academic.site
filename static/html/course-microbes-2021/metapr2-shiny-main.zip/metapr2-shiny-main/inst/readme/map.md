#### Map of the number of reads of the  selected taxon relative to the total number of eukaryotic reads.

The color of the circles represent the dominant taxon at the next rank: for example if you select a division, the dominant class at each point will be shown. Crosses indicate samples for which the group was not found.

You can select the taxonomic group as well as the type of samples on the left panel. Datasets can be selected in the tab 'Datasets