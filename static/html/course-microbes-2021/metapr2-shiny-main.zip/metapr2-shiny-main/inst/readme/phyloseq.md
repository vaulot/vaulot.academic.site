#### Phyloseq diversity analysis

Number of reads not rarefield or normalized. 

You can change the minimum number of reads an ASV must have to be considered on the left side.

For alpha diversity, smoothing is done with "gam" (general additive model)

**BE PATIENT**, plotting takes some time...